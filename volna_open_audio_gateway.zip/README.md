
# Volna Open Audio Gateway

Backend для «Волны», который ищет и проигрывает **полноценное открыто доступное аудио без регистрации и API-ключей**.

## Подключено
1. Openverse — анонимный API открытого аудио.
2. Wikimedia Commons — публичный MediaWiki API и оригинальные аудиофайлы.
3. Internet Archive — публичный advanced search + metadata API.
4. ccMixter — открытый Query API Creative Commons музыки.
5. Open.Audio / Funkwhale — публичный Funkwhale pod; libre music и зеркало Free Music Archive.

Все источники опрашиваются параллельно. Результаты приводятся к единому формату и дедуплицируются.
Проигрывание идёт через `/api/stream/<token>`: это решает большую часть проблем CORS/hotlink на iPhone/Safari и сохраняет Range-перемотку.

## Почему не включены в полнотрековый слой
- iTunes Search API: только 30-секундный preview, плюс ограничения на использование preview.
- Jamendo: client_id обязателен.
- Freesound: API credential обязателен.
- Spotify: авторизация и нет API прямых полноценных аудиофайлов.
- SoundCloud: требуются credentials приложения.
- YouTube: видео, а проект требует аудиофайлы.

## Запуск
```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Открыть `http://localhost:8000`.

## Для готового сайта из режима Работа
Разверни этот backend на HTTPS и укажи его адрес в `WORK_INTEGRATION.js`:
```js
window.VOLNA_AUDIO_GATEWAY = "https://audio.example.com";
```

Затем поиск сайта должен вызывать `volnaSearchOpenAudio(query)`, а плеер — использовать `track.audioUrl`.

## Важное ограничение
Без регистрации/ключей и без лицензии правообладателей невозможно легально получить API с полным коммерческим каталогом Spotify/Apple Music/Яндекс Музыки. Этот gateway максимально расширяет именно **открытый полнотрековый каталог**.
