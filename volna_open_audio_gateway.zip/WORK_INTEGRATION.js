
/*
  Патч для существующей "Волны" из режима Работа.
  Предполагается, что AUDIO_GATEWAY указывает на развернутый backend из этого пакета.
*/
const AUDIO_GATEWAY = window.VOLNA_AUDIO_GATEWAY || "https://YOUR-DOMAIN.example";

export async function volnaSearchOpenAudio(query, limit = 80) {
  const r = await fetch(`${AUDIO_GATEWAY}/api/search?q=${encodeURIComponent(query)}&limit=${limit}`);
  if (!r.ok) throw new Error(`audio gateway ${r.status}`);
  const j = await r.json();
  return j.tracks.map(t => ({
    id: `${t.source}:${t.provider_id || t.title}`,
    title: t.title,
    artist: t.artist,
    album: t.album || "",
    artwork: t.artwork || "",
    source: t.source,
    license: t.license || "",
    audioUrl: new URL(t.play_url, AUDIO_GATEWAY).toString(),
    playable: true,
    kind: "audio"
  }));
}

export function playVolnaTrack(audioElement, track) {
  audioElement.src = track.audioUrl;
  audioElement.playsInline = true;
  return audioElement.play();
}
