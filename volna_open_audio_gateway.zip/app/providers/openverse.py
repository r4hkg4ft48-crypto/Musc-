
from __future__ import annotations
from urllib.parse import urlsplit
from ..models import Track

API = "https://api.openverse.org/v1/audio/"

def _quality(item: dict) -> int:
    ft = (item.get("filetype") or "").lower()
    if ft == "flac": return 100
    if ft in {"m4a","aac"}: return 90
    if ft == "mp3": return 85
    if ft in {"ogg","oga","opus"}: return 80
    if ft == "wav": return 70
    return 50

async def search(client, q: str, limit: int = 25):
    r = await client.get(API, params={"q": q, "page_size": min(limit, 50)})
    r.raise_for_status()
    data = r.json()
    out = []
    for x in data.get("results", []):
        url = x.get("url")
        if not url:
            continue
        title = x.get("title") or "Без названия"
        artist = x.get("creator") or "Неизвестный исполнитель"
        out.append(Track(
            title=title,
            artist=artist,
            source="Openverse",
            source_url=x.get("foreign_landing_url") or "",
            audio_url=url,
            artwork=x.get("thumbnail") or "",
            license=(x.get("license") or "").upper(),
            mime=(x.get("filetype") or ""),
            duration=x.get("duration"),
            quality=_quality(x),
            provider_id=str(x.get("id") or ""),
        ))
    return out
