
from __future__ import annotations
from urllib.parse import quote
from ..models import Track

SEARCH = "https://archive.org/advancedsearch.php"
META = "https://archive.org/metadata/{identifier}"

AUDIO_FORMATS = (
    "VBR MP3","MP3","Ogg Vorbis","Ogg Opus","FLAC","WAVE","AAC","M4A"
)

def qscore(fmt: str, name: str) -> int:
    z = ((fmt or "") + " " + (name or "")).lower()
    if "flac" in z: return 100
    if "m4a" in z or "aac" in z: return 90
    if "mp3" in z: return 85
    if "ogg" in z or "opus" in z: return 80
    if "wav" in z or "wave" in z: return 70
    return 50

def mime_for(name: str):
    n = (name or "").lower()
    if n.endswith(".mp3"): return "audio/mpeg"
    if n.endswith(".m4a") or n.endswith(".aac"): return "audio/mp4"
    if n.endswith(".ogg") or n.endswith(".oga") or n.endswith(".opus"): return "audio/ogg"
    if n.endswith(".flac"): return "audio/flac"
    if n.endswith(".wav"): return "audio/wav"
    return ""

async def search(client, q: str, limit: int = 20):
    # IA Lucene query: search audio items by title/creator/subject.
    clean = " ".join(x for x in q.replace('"'," ").split() if x)
    lucene = f'mediatype:audio AND (title:("{clean}") OR creator:("{clean}") OR subject:("{clean}"))'
    params = {
        "q": lucene,
        "fl[]": ["identifier","title","creator"],
        "rows": min(max(4, limit//2), 12),
        "page": 1,
        "output":"json"
    }
    r = await client.get(SEARCH, params=params)
    r.raise_for_status()
    docs = r.json().get("response",{}).get("docs",[])
    out = []
    for d in docs:
        ident = d.get("identifier")
        if not ident: continue
        try:
            mr = await client.get(META.format(identifier=quote(str(ident), safe="")))
            mr.raise_for_status()
            meta = mr.json()
        except Exception:
            continue
        creator = d.get("creator")
        if isinstance(creator,list): creator = creator[0] if creator else ""
        creator = creator or "Internet Archive"
        files = []
        for f in meta.get("files",[]) or []:
            name = f.get("name") or ""
            fmt = f.get("format") or ""
            if f.get("private") is True: continue
            if name.lower().endswith((".zip",".torrent",".xml",".sqlite",".jpg",".png")): continue
            if not (name.lower().endswith((".mp3",".m4a",".aac",".ogg",".oga",".opus",".flac",".wav")) or any(z.lower() in fmt.lower() for z in AUDIO_FORMATS)):
                continue
            files.append(f)
        files.sort(key=lambda f:qscore(f.get("format",""),f.get("name","")), reverse=True)
        # return several tracks per IA item instead of only one file
        for f in files[:4]:
            name = f.get("name") or ""
            title = f.get("title") or d.get("title") or name.rsplit("/",1)[-1]
            audio = "https://archive.org/download/{}/{}".format(
                quote(str(ident),safe=""),
                "/".join(quote(p,safe="") for p in name.split("/"))
            )
            out.append(Track(
                title=str(title),
                artist=str(creator),
                source="Internet Archive",
                source_url=f"https://archive.org/details/{quote(str(ident),safe='')}",
                audio_url=audio,
                album=str(d.get("title") or ""),
                mime=mime_for(name),
                quality=qscore(f.get("format",""),name),
                provider_id=f"{ident}:{name}"
            ))
            if len(out) >= limit:
                return out
    return out
