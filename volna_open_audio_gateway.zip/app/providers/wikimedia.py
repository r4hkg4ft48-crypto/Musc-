
from __future__ import annotations
import re
from ..models import Track

API = "https://commons.wikimedia.org/w/api.php"
AUDIO_MIMES = {
    "audio/mpeg","audio/mp4","audio/ogg","audio/wav","audio/flac",
    "audio/x-flac","application/ogg"
}

def strip_html(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s or "").strip()

def quality(mime: str, url: str) -> int:
    z = (mime or "").lower() + " " + (url or "").lower()
    if "flac" in z: return 100
    if "mp4" in z or ".m4a" in z: return 90
    if "mpeg" in z or ".mp3" in z: return 85
    if "ogg" in z or "opus" in z: return 80
    if "wav" in z: return 70
    return 50

async def search(client, q: str, limit: int = 25):
    params = {
        "action":"query","format":"json","origin":"*",
        "generator":"search","gsrsearch":q,"gsrnamespace":"6",
        "gsrlimit":min(limit,50),
        "prop":"imageinfo","iiprop":"url|mime|extmetadata"
    }
    r = await client.get(API, params=params)
    r.raise_for_status()
    j = r.json()
    out = []
    for page in (j.get("query",{}).get("pages",{}) or {}).values():
        ii = (page.get("imageinfo") or [{}])[0]
        url = ii.get("url")
        mime = (ii.get("mime") or "").lower()
        if not url:
            continue
        if not (mime.startswith("audio/") or re.search(r"\.(mp3|m4a|aac|ogg|oga|opus|wav|flac)(?:$|\?)", url, re.I)):
            continue
        md = ii.get("extmetadata") or {}
        title = (md.get("ObjectName",{}).get("value") or page.get("title") or "").replace("File:","")
        artist = strip_html(md.get("Artist",{}).get("value")) or "Wikimedia Commons"
        lic = md.get("LicenseShortName",{}).get("value") or ""
        out.append(Track(
            title=title or "Без названия",
            artist=artist,
            source="Wikimedia Commons",
            source_url=(md.get("Credit",{}).get("value") or ""),
            audio_url=url,
            license=lic,
            mime=mime,
            quality=quality(mime,url),
            provider_id=str(page.get("pageid") or ""),
        ))
    return out
