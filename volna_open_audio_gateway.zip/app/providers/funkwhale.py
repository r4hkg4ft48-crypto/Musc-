
from __future__ import annotations
from ..models import Track

# Public pod run by the Funkwhale Collective. It hosts libre music and an FMA mirror.
PODS = ["https://open.audio"]

def _artist(x: dict) -> str:
    ac = x.get("artist_credit") or x.get("artistCredit")
    if isinstance(ac,list) and ac:
        parts = []
        for a in ac:
            if isinstance(a,dict):
                parts.append((a.get("credit") or a.get("name") or "").strip() + (a.get("joinphrase") or ""))
        s = "".join(parts).strip()
        if s: return s
    a = x.get("artist")
    if isinstance(a,dict): return a.get("name") or "Open.Audio"
    return str(a or "Open.Audio")

def _title(x: dict):
    return x.get("title") or x.get("name") or "Без названия"

def _cover(x: dict, base: str):
    album = x.get("album") or {}
    cover = album.get("cover") if isinstance(album,dict) else None
    if isinstance(cover,dict):
        u = cover.get("original") or cover.get("medium_square_crop") or cover.get("urls",{}).get("original")
        if u:
            return u if u.startswith("http") else base + u
    att = x.get("attachment_cover") or x.get("attachmentCover")
    if isinstance(att,dict):
        u = att.get("original") or att.get("url")
        if u: return u if u.startswith("http") else base + u
    return ""

def _listen_url(x: dict, base: str):
    # Funkwhale v1 responses often include uploads with listen_url / uuid.
    ups = x.get("uploads") or []
    if isinstance(ups,list):
        for u in ups:
            if not isinstance(u,dict): continue
            for k in ("listen_url","listenUrl"):
                z=u.get(k)
                if z: return z if z.startswith("http") else base+z
            uuid=u.get("uuid")
            if uuid: return f"{base}/api/v1/listen/{uuid}/"
    # Federation/v2 representation may expose direct listen links.
    for k in ("listen_url","listenUrl","url"):
        z=x.get(k)
        if isinstance(z,str) and ("listen" in z or z.startswith("http")):
            return z if z.startswith("http") else base+z
        if isinstance(z,dict):
            href=z.get("href")
            if href: return href if href.startswith("http") else base+href
    guid=x.get("guid")
    if guid:
        return f"{base}/api/v2/listen/{guid}/"
    return ""

async def _search_v1(client, base, q, limit):
    r=await client.get(base+"/api/v1/tracks/", params={"q":q,"page_size":min(limit,50),"include_channels":"true"})
    r.raise_for_status()
    j=r.json()
    return j.get("results",[]) if isinstance(j,dict) else []

async def _search_v2(client, base, q, limit):
    # v2 is used by newer Funkwhale pods. Query naming may vary during the v2 transition.
    candidates = ["/api/v2/tracks", "/api/v2/recordings"]
    for ep in candidates:
        try:
            r=await client.get(base+ep, params={"q":q,"page_size":min(limit,50)})
            if r.status_code==200:
                j=r.json()
                if isinstance(j,dict):
                    return j.get("results") or j.get("items") or []
                if isinstance(j,list): return j
        except Exception:
            pass
    return []

async def search(client, q: str, limit: int = 30):
    out=[]
    for base in PODS:
        try:
            rows=await _search_v1(client,base,q,limit)
        except Exception:
            rows=await _search_v2(client,base,q,limit)
        for x in rows:
            if not isinstance(x,dict): continue
            url=_listen_url(x,base)
            if not url: continue
            album=x.get("album") or {}
            album_title=album.get("title") if isinstance(album,dict) else ""
            lic=x.get("license")
            if isinstance(lic,dict): lic=lic.get("name") or lic.get("code") or ""
            out.append(Track(
                title=str(_title(x)),
                artist=_artist(x),
                source="Open.Audio / Funkwhale",
                source_url=base,
                audio_url=url,
                artwork=_cover(x,base),
                album=str(album_title or ""),
                license=str(lic or ""),
                quality=90,
                provider_id=str(x.get("id") or x.get("uuid") or x.get("guid") or "")
            ))
            if len(out)>=limit: return out
    return out
