
from __future__ import annotations
from ..models import Track

API = "https://ccmixter.org/api/query"

def _extract_files(x: dict):
    # ccHost installations have used a few shapes over the years.
    candidates = []
    for key in ("files","upload_files","download_urls"):
        val = x.get(key)
        if isinstance(val, list):
            candidates.extend(val)
        elif isinstance(val, dict):
            candidates.extend(val.values())
    for k in ("download_url","file_url","url"):
        if isinstance(x.get(k), str):
            candidates.append({"download_url":x[k]})
    return candidates

def _pick_url(f):
    if isinstance(f,str): return f
    if not isinstance(f,dict): return ""
    return f.get("download_url") or f.get("file_url") or f.get("url") or f.get("file_download_url") or ""

async def search(client, q: str, limit: int = 25):
    params = {
        "f":"json",
        "dataview":"info",
        "search":q,
        "search_type":"all",
        "limit":min(limit,50),
    }
    r = await client.get(API, params=params)
    r.raise_for_status()
    j = r.json()
    if isinstance(j, dict):
        rows = j.get("results") or j.get("items") or j.get("data") or []
    else:
        rows = j if isinstance(j,list) else []
    out = []
    for x in rows:
        if not isinstance(x,dict): continue
        files = _extract_files(x)
        for f in files:
            url = _pick_url(f)
            if not url: continue
            low = url.lower().split("?")[0]
            if not low.endswith((".mp3",".m4a",".aac",".ogg",".oga",".opus",".flac",".wav")):
                continue
            artist = x.get("user_real_name") or x.get("user_name") or x.get("upload_user_name") or "ccMixter"
            title = x.get("upload_name") or x.get("title") or "Без названия"
            lic = x.get("license_name") or x.get("license") or x.get("license_url") or ""
            out.append(Track(
                title=str(title),
                artist=str(artist),
                source="ccMixter",
                source_url=x.get("file_page_url") or x.get("upload_page_url") or "",
                audio_url=url,
                license=str(lic),
                quality=85 if ".mp3" in low else 80,
                provider_id=str(x.get("upload_id") or "")
            ))
            break
    return out
