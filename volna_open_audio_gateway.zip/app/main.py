
from __future__ import annotations
import asyncio, hashlib, time, re
from urllib.parse import urlsplit
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
import httpx

from .models import Track
from .providers import openverse, wikimedia, archive, ccmixter, funkwhale

app = FastAPI(title="Volna Open Audio Gateway", version="1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=False,
    allow_methods=["GET","OPTIONS"], allow_headers=["*"]
)

PROVIDERS = {
    "openverse": openverse.search,
    "wikimedia": wikimedia.search,
    "archive": archive.search,
    "ccmixter": ccmixter.search,
    "funkwhale": funkwhale.search,
}

# Server-side token cache: clients never choose arbitrary proxy URLs.
STREAMS: dict[str, tuple[float, str]] = {}
TTL = 60 * 60 * 6

ALLOWED_HOSTS = {
    "api.openverse.org", "commons.wikimedia.org", "upload.wikimedia.org",
    "archive.org", "ia800000.us.archive.org", "ccmixter.org", "open.audio"
}
ALLOWED_SUFFIXES = (
    ".archive.org", ".us.archive.org", ".wikimedia.org",
    ".wordpress.com", ".wp.com", ".open.audio"
)

def host_allowed(url: str) -> bool:
    try:
        u=urlsplit(url)
        if u.scheme not in {"http","https"}: return False
        h=(u.hostname or "").lower()
        return h in ALLOWED_HOSTS or any(h.endswith(s) for s in ALLOWED_SUFFIXES)
    except Exception:
        return False

def stream_token(url: str) -> str:
    # deterministic opaque handle; actual URL remains only server-side
    tok=hashlib.sha256(url.encode()).hexdigest()[:32]
    STREAMS[tok]=(time.time()+TTL,url)
    return tok

def clean_cache():
    now=time.time()
    for k,(exp,_) in list(STREAMS.items()):
        if exp<now: STREAMS.pop(k,None)

def norm_text(s: str):
    return re.sub(r"[^a-zа-яё0-9]+"," ",(s or "").lower(),flags=re.I).strip()

def dedupe_rank(items: list[Track], q: str):
    seen={}
    qn=norm_text(q)
    for t in items:
        key=norm_text(t.artist+" "+t.title)
        if not key: continue
        # Query relevance boost + quality + provider diversity.
        rel=40 if qn and qn in key else 0
        score=t.quality+rel
        prev=seen.get(key)
        if prev is None or score>prev[0]:
            seen[key]=(score,t)
    out=[v[1] for v in seen.values()]
    out.sort(key=lambda t: (-(40 if qn in norm_text(t.artist+" "+t.title) else 0), -t.quality, t.artist.lower(), t.title.lower()))
    return out

@app.get("/health")
async def health():
    return {"ok":True,"mode":"anonymous-open-audio","providers":list(PROVIDERS)}

@app.get("/api/providers")
async def providers():
    return {
        "active":[
            {"id":"openverse","name":"Openverse","registration":False,"full_audio":True},
            {"id":"wikimedia","name":"Wikimedia Commons","registration":False,"full_audio":True},
            {"id":"archive","name":"Internet Archive","registration":False,"full_audio":True},
            {"id":"ccmixter","name":"ccMixter","registration":False,"full_audio":True},
            {"id":"funkwhale","name":"Open.Audio / Funkwhale","registration":False,"full_audio":True,
             "note":"Libre music + Free Music Archive mirror"},
        ],
        "intentionally_excluded":[
            {"name":"iTunes Search","reason":"30-second preview only; not for a full-track entertainment player"},
            {"name":"Jamendo","reason":"client_id required"},
            {"name":"Freesound","reason":"API credential required"},
            {"name":"Spotify","reason":"authentication required and no full audio file API"},
            {"name":"SoundCloud","reason":"app credentials required"},
        ]
    }

@app.get("/api/search")
async def search(
    q: str = Query(..., min_length=1, max_length=160),
    limit: int = Query(60, ge=1, le=150)
):
    clean_cache()
    timeout=httpx.Timeout(12.0, connect=6.0)
    headers={"User-Agent":"VolnaOpenAudio/1.0 (+https://example.invalid)"}
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True, headers=headers) as client:
        jobs=[fn(client,q,min(35,limit)) for fn in PROVIDERS.values()]
        results=await asyncio.gather(*jobs, return_exceptions=True)
    tracks=[]
    provider_status={}
    for name,res in zip(PROVIDERS,results):
        if isinstance(res,Exception):
            provider_status[name]={"ok":False,"error":res.__class__.__name__}
        else:
            provider_status[name]={"ok":True,"count":len(res)}
            tracks.extend(res)
    tracks=dedupe_rank(tracks,q)[:limit]
    public=[]
    for t in tracks:
        if not host_allowed(t.audio_url):
            continue
        tok=stream_token(t.audio_url)
        public.append(t.public(f"/api/stream/{tok}"))
    return {"query":q,"count":len(public),"providers":provider_status,"tracks":public}

@app.get("/api/stream/{token}")
async def stream(token: str, request: Request):
    clean_cache()
    item=STREAMS.get(token)
    if not item:
        raise HTTPException(404,"stream expired")
    _,url=item
    if not host_allowed(url):
        raise HTTPException(403,"source not allowed")
    range_header=request.headers.get("range")
    headers={"User-Agent":"VolnaOpenAudio/1.0"}
    if range_header:
        headers["Range"]=range_header
    client=httpx.AsyncClient(timeout=httpx.Timeout(30.0,read=60.0), follow_redirects=True, headers=headers)
    try:
        upstream=await client.send(client.build_request("GET",url),stream=True)
    except Exception as e:
        await client.aclose()
        raise HTTPException(502,"upstream unavailable")
    if upstream.status_code not in (200,206):
        await upstream.aclose(); await client.aclose()
        raise HTTPException(502,f"upstream status {upstream.status_code}")
    response_headers={}
    for h in ("content-type","content-length","content-range","accept-ranges","etag","last-modified"):
        if h in upstream.headers:
            response_headers[h]=upstream.headers[h]
    response_headers["Cache-Control"]="public, max-age=3600"
    async def body():
        try:
            async for chunk in upstream.aiter_bytes(64*1024):
                yield chunk
        finally:
            await upstream.aclose()
            await client.aclose()
    return StreamingResponse(body(), status_code=upstream.status_code,
                             media_type=upstream.headers.get("content-type","audio/mpeg"),
                             headers=response_headers)

@app.get("/")
async def root():
    return FileResponse("static/index.html")
