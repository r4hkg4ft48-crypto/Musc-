
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class Track:
    title: str
    artist: str
    source: str
    source_url: str
    audio_url: str
    artwork: str = ""
    album: str = ""
    license: str = ""
    mime: str = ""
    duration: Optional[float] = None
    quality: int = 0
    provider_id: str = ""

    def public(self, play_url: str) -> dict:
        d = asdict(self)
        d.pop("audio_url", None)
        d["play_url"] = play_url
        return d
